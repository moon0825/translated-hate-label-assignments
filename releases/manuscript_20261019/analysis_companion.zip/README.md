# Learning from Translated Hate-Speech Annotations: Label Assignments and Detection Costs

This companion contains the numerical results and verification code for the
manuscript and its supplement. Start here to check the complete set of analyses.

## Reproduce the reported statistics

Use Python 3.12 or later, install the dependencies, then run:

```sh
python -m pip install -r requirements.txt
python -B reproduce.py --output ../reproduction_results
```

Choose an output directory outside this companion. The command checks the file
checksums and verifies the main factorial comparisons, EXAONE and Gemma
supervision controls, KOLD and APEACH evaluations, instruction-boundary
comparison, and descriptive error analyses. The final
report is `verification.json` in the selected output directory. A successful run
reports `"status": "PASS"`.

The verification uses saved run-level metrics, and integer confusion counts. It reconstructs paired differences, pointwise
confidence intervals, and the specified Holm corrections. Re-running training, translation,
or annotation requires the corresponding
model environments and underlying text or response data.

## Find a result

Paths below are relative to `analysis/`. Tables refer to the current English
manuscript and supplement; S denotes a supplementary table.

| Manuscript result | Numerical files |
|---|---|
| Table 5, Figure 1 and Tables S32–S37: EXAONE supervision controls and target losses | `data/control_run_metrics.csv`, `data/control_paired_contrasts.csv`, `data/control_target_recall.csv`, `data/target_lw_*.csv` |
| Tables 6 and S41–S44: Gemma supervision controls | `data/gemma_20261010/` |
| Table 10, Figure 4 and Tables S4–S13: main factorial means and 44 paired comparisons | `data/run_metrics.csv`, `data/paired_contrasts.csv` |
| Table 9 and Tables S20–S27: class and target recall | `data/diagnostic_tables/subgroup_*.csv`, `data/target_recall_reproduction.csv` |
| Tables S15–S19: annotation transitions and label proportions | `data/diagnostic_tables/transition*.csv` |
| Table 8 and Tables S38–S40: KOLD relabel-versus-source evaluation | `data/kold_cell_metrics.csv`, `data/kold_contrasts.csv`, `data/kold_strata.csv` |
| Table 7 (KOLD columns) and Tables S45–S48: KOLD supervision controls | `data/kold_controls_20261010/` |
| Table 7 (APEACH columns) and Tables S49–S51: APEACH supervision controls | `data/apeach_controls_20261010/` |
| Table 11 and Tables S52–S56: instruction-boundary A/B comparison | `data/policy_boundary_20261010/` |
| Appendix A (Tables A.1–A.2): threshold-free AUROC and prior-matched macro-F1 | `../appendix_a/cells_threshold_free.csv`, `../appendix_a/paired_threshold_free.csv`, `../appendix_a/all_negative_counts.csv` |
| Supplementary Section S13: comment error frequency and overlapping targets | `data/cpu_20261010/`, `data/target_lw_turnover*.csv` |
| Tables 1–4, S1–S3, S14 and S28: procedures, settings and development history | Manuscript and supplement; `data/model_metadata.json`, `data/execution_metadata.json`, `reproducibility/` support model and assignment details |

Each CSV directory includes the full condition or subgroup results described in
the supplement. In the external and boundary directories, `cells.csv` contains
run-level confusion counts, `arm_summaries.csv` contains condition means, and
`primary.csv` contains the specified comparisons. `reproducibility/README.md`
explains the original training-row identifiers and ordering.

## Read conditions and units

S uses source labels inherited from the English datasets. L uses task-guided relabels. W retains source
labels and weights each source-corpus/class cell to match its L class count.
P reassigns L labels within source-corpus/source-label strata. The translator
and annotator setting is identified separately in each file.

F1, recall and accuracy use the 0–1 scale; the manuscript reports them ×100 as points.
Target masks may
overlap. Import `signature_bits` as text to preserve leading zeros.

Holm correction is applied within each comparison family: 44 main contrasts;
four primary and 14 target contrasts for each within-corpus supervision study;
eight original KOLD contrasts; eight KOLD controls; eight APEACH controls; and
12 instruction-boundary contrasts. Descriptive comparisons have blank p fields.
An adjusted p value of 1 is a valid result of the Holm calculation. The
supplement specifies the historical zero/undefined conventions for secondary MCC.

## Protocols and access

The supplement provides translation messages (Section S2), annotation
instructions and their English translation (S3), and the four A/B additions
(S17). Offensive example wording is redacted in the public protocols. During
review, requests for the unredacted executed instructions can be
directed to the corresponding author through the journal's editorial office,
subject to the applicable data-use restrictions.

Obtain the original corpora from the distributors cited in the manuscript.
The numerical release contains text-free training assignments and contains no
human-audit data. Dataset and model reuse follows each
provider's terms. A separate reuse license for this numerical release is pending.

## Versioned contents

`analysis/` holds the verified numerical release without its human-audit files,
which were removed on 18 November 2026; its earlier documentation is otherwise kept. This README and the top-level command
provide the current entry point. `appendix_a/` holds the per-run and paired threshold-free results for Appendix A of the manuscript. `SHA256SUMS.txt` covers the complete companion.
